package com.example.zoom_colne_with_jitsi;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
