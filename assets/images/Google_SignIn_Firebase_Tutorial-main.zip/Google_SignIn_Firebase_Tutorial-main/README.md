# zoom_colne_with_jitsi

##### In this tutorial, you will learn how to use Firebase to 
- Auth users with Google Sign In using Firebase 
- save user data to Firestore 
- show a stream of this data on your app (live data)
- create a nested collection -  
- log a user out 

#### Watch The Tutoial 👉🏻 https://youtu.be/tWraEokVD_k

## See Screenshots

<table>
  <tr>
    <td></td>
     <td></td>
     <td></td>
  </tr>
  <tr>
    <td><img src="ScreenShot/1.jpg" </td>
    <td><img src="ScreenShot/2.jpg" ></td>
    <td><img src="ScreenShot/3.jpg" ></td>
  </tr>
   
  <tr>
    <td><img src="ScreenShot/4.jpg" </td>
    <td><img src="ScreenShot/5.jpg" </td>
  </tr>
  
 </table>
